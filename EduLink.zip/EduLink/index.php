<?php
// Inclure votre fichier de connexion à la base de données
include('sql.php');

// Initialiser les variables avec une valeur par défaut
$total_enseignants = 0;
$total_forums = 0;
$total_commentaires = 0;

// Effectuer la requête pour compter le nombre d'enseignants
$query_enseignants = "SELECT COUNT(*) AS total_enseignants FROM enseignant";
$result_enseignants = $mysqli->query($query_enseignants);

// Vérifier si la requête a été exécutée avec succès et si elle a renvoyé des résultats
if ($result_enseignants && $result_enseignants->num_rows > 0) {
    $row_enseignants = $result_enseignants->fetch_assoc();
    $total_enseignants = $row_enseignants['total_enseignants'];
}

// Effectuer la requête pour compter le nombre de forums
$query_forums = "SELECT COUNT(*) AS total_forums FROM forum";
$result_forums = $mysqli->query($query_forums);

// Vérifier si la requête a été exécutée avec succès et si elle a renvoyé des résultats
if ($result_forums && $result_forums->num_rows > 0) {
    $row_forums = $result_forums->fetch_assoc();
    $total_forums = $row_forums['total_forums'];
}

// Effectuer la requête pour compter le nombre de commentaires
$query_commentaires = "SELECT COUNT(*) AS total_commentaires FROM commentaire";
$result_commentaires = $mysqli->query($query_commentaires);

// Vérifier si la requête a été exécutée avec succès et si elle a renvoyé des résultats
if ($result_commentaires && $result_commentaires->num_rows > 0) {
    $row_commentaires = $result_commentaires->fetch_assoc();
    $total_commentaires = $row_commentaires['total_commentaires'];
}

// Fermer la connexion à la base de données
$mysqli->close();
?>
<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
  <meta charset="UTF-8" />
  <title>Enseignants</title>
  <link rel="stylesheet" href="style.css" />
  <!-- Boxicons CDN Link -->
  <link
    href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css"
    rel="stylesheet"
  />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    table {
      width: 100%;
      border-collapse: collapse;
    }
    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    th {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class='bx bx-link-alt'></i>         
       <span class="logo_name">EduLink</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="index.php" class="active">
          <i class="bx bx-user"></i>
          <span class="links_name">Gestion Enseignants</span>
        </a>
      </li>
      <li class="log_out">
        <a href="authentification.html">
          <i class="bx bx-log-out"></i>
          <span class="links_name">Déconnexion</span>
        </a>
      </li>
    </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class="bx bx-menu sidebarBtn"></i>
      </div>
      <div class="profile-details">
        <img src="logo_edulink.png" alt="logo">
      </div>
    </nav>
   
    <div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Forums </div>
            <center><div class="number"><?php echo $total_forums; ?></div></center>
            <div class="indicator">
              <i class='bx bxs-conversation'></i>        
                      <span class="text">Depuis hier</span>
            </div>
          </div>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Commentaires </div>
            <center><div class="number"><?php echo $total_commentaires; ?></div></center>
            <div class="indicator">
              <i class='bx bx-message-rounded-add'></i>    
                          <span class="text">Depuis hier</span>
            </div>
          </div>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Enseignants</div>
            <center><div class="number"><?php echo $total_enseignants; ?></div></center>
            <div class="indicator">
              <i class='bx bxs-user-account'></i>          
                    <span class="text">Depuis hier</span>
            </div>
          </div>
        </div>
      </div>

      <div class="sales-boxes">
        <div class="recent-sales box">
          <div class="title">Enseignants ajoutés </div>
          <div class="sales-details">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nom</th>
                  <th>Prénom</th>
                  <th>Université</th>
                  <th>Département</th>
                </tr>
              </thead>
              <tbody>
                <?php
                session_start() ;
                // Include your database connection file
                include('sql.php');

                // Select recent forums
                $query = "SELECT identifiant ,nom, prenom, universite, departement FROM enseignant  "; // Adjust the query as needed
                $result = $mysqli->query($query);

                // Check if there are any recent forums
                if ($result && $result->num_rows > 0) {
                  while ($row = $result->fetch_assoc()) {
                    ?>
                    <tr>
                    <td><a href="profil_détails.php?id=<?php echo $row['identifiant']; ?>"><?php echo $row['identifiant']; ?></a></td>
                      <td><?php echo $row['nom']; ?></td>
                      <td><?php echo $row['prenom']; ?></td>
                      <td><?php echo $row['universite']; ?></td>
                      <td><?php echo $row['departement']; ?></td>
                    </tr>
                    <?php
                  }
                  $result->free();
                } else {
                  ?>
                  <tr>
                    <td colspan="5">Aucun Enseignant trouvé.</td>
                  </tr>
                  <?php
                }

                // Close the database connection
                $mysqli->close();
                ?>
              </tbody>
            </table>
          </div>
          <div class="button">
            <a href="ajout_profil.html">Ajouter Un Enseignant</a>
          </div>
        </div>
        <div class="top-sales box">
            <div class="title">Enseignants par Université</div>
            <ul class="top-sales-details">
              <li>
                <a href="#">
                 <img src="images.png" alt="">
                  <span class="product">ESB</span>
                </a>
                <span class="price">12 Enseignants</span>
              </li>
              <li>
                <a href="#">
                  <img src="universite-lyon-1.png" alt="">
                  <span class="product">UCBL</span>
                </a>
                <span class="price">4 Enseignants</span>
              </li>   
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>

  <script>
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
    sidebarBtn.onclick = function () {
      sidebar.classList.toggle("active");
      if (sidebar.classList.contains("active")) {
        sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
      } else sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
    };
  </script>
</body>
</html>
