<?php
// Vérifier si l'identifiant de l'enseignant est passé en tant que paramètre dans l'URL
if(isset($_GET['id'])) {
    // Récupérer l'identifiant de l'enseignant depuis l'URL
    $identifiant = $_GET['id'];

    // Inclure votre fichier de connexion à la base de données
    include('sql.php');

    // Utiliser l'identifiant pour récupérer les détails du profil de l'enseignant depuis la base de données
    $query = "SELECT nom, prenom, email, universite, departement FROM enseignant WHERE identifiant = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $identifiant);
    $stmt->execute();
    $result = $stmt->get_result();

    // Vérifier s'il y a des résultats
    if($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nom = $row['nom'];
        $prenom = $row['prenom'];
        $email = $row['email'];
        $universite = $row['universite'];
        $departement = $row['departement'];
    } else {
        // Si aucun enseignant correspondant n'est trouvé, redirigez l'utilisateur
        header("Location: forum.php");
        exit();
    }

    // Fermer la connexion à la base de données
    $mysqli->close();
} else {
    // Si aucun identifiant n'est passé en tant que paramètre dans l'URL, redirigez l'utilisateur
    header("Location: forum.php");
    exit();
}
?>

<!-- Votre code HTML pour afficher les détails du profil de l'enseignant -->


<!DOCTYPE html>
<html lang="fr" dir="ltr">

<head>
  <meta charset="UTF-8" />
  <title>Profil</title>
  <link rel="stylesheet" href="style.css" />
  <!-- Boxicons CDN Link -->
  <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

</head>

<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class='bx bx-link-alt'></i>         
      <span class="logo_name">EduLink</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="index.php" >
          <i class="bx bx-user"></i>
          <span class="links_name">Gestion Enseignants</span>
        </a>
      </li>
      <li class="log_out">
        <a href="authentification.html">
          <i class="bx bx-log-out"></i>
          <span class="links_name">Déconnexion</span>
        </a>
      </li>
    </ul>
  </div>

  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class="bx bx-menu sidebarBtn"></i>
      </div>
      <div class="profile-details">
        <img src="logo_edulink.png" alt="logi">
      </div>
    </nav>
   
    <div class="home-content">
      <!-- Profile Section -->
<div class="profile-section">
  <div class="profile-details">
    <div class="profile-info">
      <span class="name"><?php echo isset($nom) ? $nom : ''; ?> <?php echo isset($prenom) ? $prenom : ''; ?></span>
      <span class="subject"></span>
    </div>
    <div>
    <a href="supprimer_profil.php?id=<?php echo $identifiant; ?>" class="edit-profile-btn">Supprimer</a>
    </div> 
  </div>
</div>

<!-- Ajoutez ce script pour afficher le chemin de l'image dans la console -->

<!-- Personal Information Section -->
<div class="profile-attributes">
  <h2>Informations personnelles</h2>
  <ul>
    <li>
      <div>
        <strong>Nom:</strong>
        <span><?php echo isset($nom) ? $nom : ''; ?></span>
      </div>
    </li>
    <li>
      <div>
        <strong>Prénom:</strong>
        <span><?php echo isset($prenom) ? $prenom : ''; ?></span>
      </div>
    </li>
    <li>
      <div>
        <strong>Email:</strong>
        <span><?php echo isset($email) ? $email : ''; ?></span>
      </div>  
    </li>
    <li>
      <div>
        <strong>Université : </strong>
        <span><?php echo isset($universite) ? $universite : ''; ?></span>
      </div>  
    </li>
    <li>
      <div>
        <strong>Département : </strong>
        <span><?php echo isset($departement) ? $departement : ''; ?></span>
      </div>  
    </li>
  </ul>
</div>

    </div>
  </section>

  <script>
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
    sidebarBtn.onclick = function () {
      sidebar.classList.toggle("active");
      if (sidebar.classList.contains("active")) {
        sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
      } else sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
    };

   
  </script>

  <style>
    /* Styles CSS du code initial */
    .home-content .profile-section {
      background: #fff;
      padding: 20px;
      margin: 20px;
      border-radius: 12px;
      box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
    }

    .profile-details {
      display: flex;
      align-items: center;
      justify-content: space-between; /* Ajout d'un espacement équitable entre les éléments */
    }

    .profile-details img {
      height: 80px;
      width: 80px;
      border-radius: 50%;
      object-fit: cover;
      margin-right: 20px;
    }

    .profile-info {
      flex-grow: 1;
      margin-bottom: 10px; 
    }

    .profile-info .name {
      font-size: 24px;
      font-weight: 500;
      color: #333;
    }

    .profile-info .subject {
      font-size: 18px;
      color: #777;
      margin-bottom: 10px;
    }

    .edit-profile-btn {
      padding: 6px 12px;
      background-color: black;
      color: #fff;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 14px;
      transition: background-color 0.3s ease;
      text-decoration: none; /* Ajout de la suppression du soulignement */
    }

    .edit-profile-btn:hover {
      background-color: #2d78a9;
    }

    /* Styles pour la section d'informations personnelles */
    .profile-attributes {
      background: #f5f5f5;
      padding: 20px;
      margin: 20px;
      border-radius: 12px;
      box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
    }

    .profile-attributes h2 {
      font-size: 24px;
      font-weight: 500;
      color: #333;
      margin-bottom: 15px;
    }

    .profile-attributes ul {
      list-style: none;
      padding: 0;
    }

    .profile-attributes li {
      margin-bottom: 10px;
      display: flex;
      flex-direction: column; /* Afficher chaque attribut et son bouton verticalement */
    }

    .profile-attributes li strong {
      display: inline-block;
      width: 120px;
      font-weight: 500;
    }
  </style>
</body>

</html>
