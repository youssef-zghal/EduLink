<?php
// Vérifier si l'identifiant de l'enseignant est passé en tant que paramètre dans l'URL
if(isset($_GET['id'])) {
    // Récupérer et nettoyer l'identifiant de l'enseignant depuis l'URL
    $identifiant = $_GET['id'];

    // Inclure votre fichier de connexion à la base de données
    include('sql.php');

    // Préparer la requête de suppression
    $query = "DELETE FROM enseignant WHERE identifiant = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $identifiant);

    // Exécuter la requête de suppression
    if($stmt->execute()) {
        // Redirection vers la page forum.php après la suppression
        header("Location: index.php");
        exit();
    } else {
        // En cas d'échec de la suppression, afficher un message d'erreur
        echo "Erreur lors de la suppression de l'enseignant.";
    }

    // Fermer la connexion à la base de données
    $mysqli->close();
} else {
    // Si aucun identifiant n'est passé en tant que paramètre dans l'URL, afficher un message d'erreur
    echo "Identifiant de l'enseignant non spécifié.";
}
?>
