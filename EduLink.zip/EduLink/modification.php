<?php
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['enseignant_id']) || empty($_SESSION['enseignant_id'])) {
    header("Location: authentification.html"); // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
    exit;
}

// Vérifier si le formulaire de modification est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_update'])) {
    // Récupérer l'identifiant de l'enseignant connecté
    $enseignant_id = $_SESSION['enseignant_id'];

    // Récupérer les données du formulaire
    $attribut = $_POST['attribute'];
    $nouvelle_valeur = $_POST['new-value'];

    // Inclure le fichier de connexion à la base de données
    include('sql.php');

    // Préparer et exécuter la requête de mise à jour en fonction de l'attribut choisi
    switch ($attribut) {
        case "nom":
            $update_query = "UPDATE enseignant SET nom = ? WHERE identifiant = ?";
            break;
        case "prenom":
            $update_query = "UPDATE enseignant SET prenom = ? WHERE identifiant = ?";
            break;
        case "email":
            $update_query = "UPDATE enseignant SET email = ? WHERE identifiant = ?";
            break;
        case "universite":
            $update_query = "UPDATE enseignant SET universite = ? WHERE identifiant = ?";
            break;
        default:
            die("Attribut non valide");
    }

    // Préparer la requête
    $statement = $mysqli->prepare($update_query);

    if ($statement) {
        // Lier les paramètres et exécuter la requête
        $statement->bind_param("ss", $nouvelle_valeur, $enseignant_id);
        if ($statement->execute()) {
            // Rediriger l'utilisateur vers la page de profil après la mise à jour
            header("Location: profil.php");
            exit;
        } else {
            echo "Erreur lors de la mise à jour de l'attribut : " . $mysqli->error;
        }

        // Fermer le statement
        $statement->close();
    } else {
        // Erreur de préparation de la requête
        echo "Erreur de préparation de la requête : " . $mysqli->error;
    }

    // Fermer la connexion à la base de données
    $mysqli->close();
}
?>
