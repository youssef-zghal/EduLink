<?php
session_start();

// Vérifier si l'utilisateur est connecté
if(isset($_SESSION['enseignant_id'])) {
    // Les données de l'utilisateur sont accessibles dans $_SESSION
    $nom = $_SESSION['enseignant_nom'];
    $prenom = $_SESSION['enseignant_prenom'];
    $email = $_SESSION['enseignant_email'];
    $universite = $_SESSION['enseignant_universite'];
    $departement = $_SESSION['enseignant_departement'];

   

    // Ajoutez d'autres attributs ici en les récupérant de la session
} else {
    // Si l'utilisateur n'est pas connecté, redirigez-le vers la page d'authentification
    header("Location: authentification.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr" dir="ltr">

<head>
  <meta charset="UTF-8" />
  <title>Profil</title>
  <link rel="stylesheet" href="style.css" />
  <!-- Boxicons CDN Link -->
  <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

</head>

<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class='bx bx-link-alt'></i>         
      <span class="logo_name">EduLink</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="profil.php" class="active">
          <i class="bx bx-user"></i>
          <span class="links_name">Profil</span>
        </a>
      </li>
      <li>
        <a href="forum.php" >
          <i class="bx bx-list-ul"></i>
          <span class="links_name">Forums</span>
        </a>
      </li>
      <li class="log_out">
        <a href="authentification.html">
          <i class="bx bx-log-out"></i>
          <span class="links_name">Déconnexion</span>
        </a>
      </li>
    </ul>
  </div>

  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class="bx bx-menu sidebarBtn"></i>
      </div>
      <div class="profile-details">
        <img src="logo_edulink.png" alt="logi">
      </div>
    </nav>
   
    <div class="home-content">
      <!-- Profile Section -->
<div class="profile-section">
  <div class="profile-details">
    <div class="profile-info">
      <span class="name"><?php echo isset($nom) ? $nom : ''; ?> <?php echo isset($prenom) ? $prenom : ''; ?></span>
      <span class="subject"></span>
    </div>
    <div>
      <a href="modification.html" class="edit-profile-btn">Modifier</a>
    </div> 
  </div>
</div>

<!-- Ajoutez ce script pour afficher le chemin de l'image dans la console -->

<!-- Personal Information Section -->
<div class="profile-attributes">
  <h2>Informations personnelles</h2>
  <ul>
    <li>
      <div>
        <strong>Nom:</strong>
        <span><?php echo isset($nom) ? $nom : ''; ?></span>
      </div>
    </li>
    <li>
      <div>
        <strong>Prénom:</strong>
        <span><?php echo isset($prenom) ? $prenom : ''; ?></span>
      </div>
    </li>
    <li>
      <div>
        <strong>Email:</strong>
        <span><?php echo isset($email) ? $email : ''; ?></span>
      </div>  
    </li>
    <li>
      <div>
        <strong>Université : </strong>
        <span><?php echo isset($universite) ? $universite : ''; ?></span>
      </div>  
    </li>
    <li>
      <div>
        <strong>Département : </strong>
        <span><?php echo isset($departement) ? $departement : ''; ?></span>
      </div>  
    </li>
  </ul>
</div>

    </div>
  </section>

  <script>
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
    sidebarBtn.onclick = function () {
      sidebar.classList.toggle("active");
      if (sidebar.classList.contains("active")) {
        sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
      } else sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
    };

   
  </script>

  <style>
    /* Styles CSS du code initial */
    .home-content .profile-section {
      background: #fff;
      padding: 20px;
      margin: 20px;
      border-radius: 12px;
      box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
    }

    .profile-details {
      display: flex;
      align-items: center;
      justify-content: space-between; /* Ajout d'un espacement équitable entre les éléments */
    }
    
    .profile-info {
      flex-grow: 1;
      margin-bottom: 10px; 
    }

    .profile-info .name {
      font-size: 24px;
      font-weight: 500;
      color: #333;
    }

    .profile-info .subject {
      font-size: 18px;
      color: #777;
      margin-bottom: 10px;
    }

    .edit-profile-btn {
      padding: 6px 12px;
      background-color: black;
      color: #fff;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 14px;
      transition: background-color 0.3s ease;
      text-decoration: none; /* Ajout de la suppression du soulignement */
    }

    .edit-profile-btn:hover {
      background-color: #2d78a9;
    }

    /* Styles pour la section d'informations personnelles */
    .profile-attributes {
      background: #f5f5f5;
      padding: 20px;
      margin: 20px;
      border-radius: 12px;
      box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
    }

    .profile-attributes h2 {
      font-size: 24px;
      font-weight: 500;
      color: #333;
      margin-bottom: 15px;
    }

    .profile-attributes ul {
      list-style: none;
      padding: 0;
    }

    .profile-attributes li {
      margin-bottom: 10px;
      display: flex;
      flex-direction: column; /* Afficher chaque attribut et son bouton verticalement */
    }

    .profile-attributes li strong {
      display: inline-block;
      width: 120px;
      font-weight: 500;
    }
  </style>
</body>

</html>
