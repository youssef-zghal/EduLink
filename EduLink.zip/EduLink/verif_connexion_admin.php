<?php
include 'sql.php'; 


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire
    $identifiant = $_POST["txt1"];
    $mot_de_passe = $_POST["pswd1"];

    // Utiliser une requête préparée pour éviter les injections SQL
    $stmt = $mysqli->prepare("SELECT * FROM administrateur WHERE identifiant=? AND mot_de_passe=?");

    // Vérifier si la préparation de la requête a réussi
    if ($stmt) {
        // Binder les paramètres
        $stmt->bind_param("ss", $identifiant, $mot_de_passe);

        // Exécuter la requête
        $stmt->execute();

        // Récupérer le résultat
        $result = $stmt->get_result();

        // Vérifier l'authentification
        if ($result->num_rows == 1) {
            header("Location: index.php");
        } else {
            // Authentification échouée
            header("Location: failed.html");
        }

      
        $stmt->close();
    } else {
        // Erreur de préparation de la requête
        die("Erreur de préparation de la requête: " . $mysqli->error);
    }
}

// Fermer la connexion à la base de données (si nécessaire)
$mysqli->close();
?>
