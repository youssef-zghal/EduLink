<?php
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['enseignant_id']) || empty($_SESSION['enseignant_id'])) {
    header("Location: authentification.html"); // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
    exit;
}

// Vérifier si les identifiants du commentaire et du forum sont passés dans l'URL
if (isset($_GET['id'], $_GET['forum_id'])) {
    $commentaire_id = intval($_GET['id']);
    $forum_id = intval($_GET['forum_id']);

    // Inclure le fichier de connexion à la base de données
    include('sql.php');

    // Récupérer l'identifiant de l'enseignant connecté
    $enseignant_id = $_SESSION['enseignant_id'];

    // Vérifier si l'utilisateur est l'auteur du commentaire
    $query = "SELECT enseignant, commentaire FROM commentaire WHERE id_commentaire = $commentaire_id";
    $result = $mysqli->query($query);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $comment_author_id = $row['enseignant'];
        $commentaire_actuel = $row['commentaire'];

        if ($comment_author_id == $enseignant_id) {
            // L'utilisateur est autorisé à modifier le commentaire

            // Vérifier si le formulaire de modification est soumis
            if (isset($_POST['submit_update']) && isset($_POST['nouveau_commentaire'])) {
                // Échapper les données du formulaire pour éviter les attaques par injection SQL
                $nouveau_commentaire = $mysqli->real_escape_string($_POST['nouveau_commentaire']);

                // Requête de modification du commentaire
                $update_query = "UPDATE commentaire SET commentaire = '$nouveau_commentaire' WHERE id_commentaire = $commentaire_id";
                $update_result = $mysqli->query($update_query);

                if ($update_result) {
                    // Rafraîchir la page pour afficher le commentaire modifié
                    header("Location: forum_détails.php?id=$forum_id");
                    exit;
                } else {
                    echo "Erreur lors de la modification du commentaire.";
                }
            }
        } else {
            // L'utilisateur n'est pas autorisé à modifier ce commentaire
            echo "Vous n'êtes pas autorisé à modifier ce commentaire.";
        }
    } else {
        // Commentaire non trouvé dans la base de données
        echo "Commentaire non trouvé.";
    }

    // Fermer le résultat et la connexion à la base de données
    $result->close();
    $mysqli->close();
} else {
    // Identifiants du commentaire ou du forum non spécifiés dans l'URL
    echo "Identifiants du commentaire ou du forum non spécifiés.";
}
?>

<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
    <meta charset="UTF-8" />
    <title>Modification du commentaire</title>
    <link rel="stylesheet" href="style.css" />
    <!-- Boxicons CDN Link -->
    <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
       
        nav  {
        margin-top: -20px; }
        .sidebar {
        margin-top: -20px; }
        body {
            font-family: Arial, sans-serif;
            margin: ;
            padding: 0;
            background-color: #f2f2f2;
        }

        .container {
            max-width: 800px;
            margin : 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .forum-box {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            margin-top:90px;
        }

        .forum-title {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }

        .commentaire {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .commentaire p {
            margin-bottom: 10px;
        }

        .commentaire textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            resize: vertical;
            margin-bottom: 10px;
        }

        .commentaire input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .commentaire input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo-details">
            <i class='bx bx-link-alt'></i>
            <span class="logo_name">EduLink</span>
        </div>
        <ul class="nav-links">
            <li>
                <a href="profil.php" class="active">
                    <i class="bx bx-user"></i>
                    <span class="links_name">Profil</span>
                </a>
            </li>
            <li>
                <a href="forum.php">
                    <i class="bx bx-list-ul"></i>
                    <span class="links_name">Forums</span>
                </a>
            </li>
            <li class="log_out">
                <a href="authentification.html">
                    <i class="bx bx-log-out"></i>
                    <span class="links_name">Déconnexion</span>
                </a>
            </li>
        </ul>
    </div>

    <section class="home-section">
        <nav>
            <div class="sidebar-button">
                <i class="bx bx-menu sidebarBtn"></i>
            </div>
            <div class="profile-details">
                <img src="logo_edulink.png" alt="logo">
            </div>
        </nav>

        <div class="container">
            <div class="forum-box">
                <h2 class="forum-title">Modification du commentaire</h2>
            </div>

            <!-- Affichage du commentaire actuel et formulaire de modification -->
            <div class="commentaire">
                <p><?php echo $commentaire_actuel; ?></p>
                <form method="post">
                    <textarea id="nouveau_commentaire" name="nouveau_commentaire" rows="4" cols="50"><?php echo $commentaire_actuel; ?></textarea><br>
                    <input type="submit" name="submit_update" value="Modifier le commentaire">
                </form>
            </div>
        </div>
    </section>

    <script>
        let sidebar = document.querySelector(".sidebar");
        let sidebarBtn = document.querySelector(".sidebarBtn");
        sidebarBtn.onclick = function () {
            sidebar.classList.toggle("active");
            if (sidebar.classList.contains("active")) {
                sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
            } else sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
        };
    </script>
</body>
</html>
