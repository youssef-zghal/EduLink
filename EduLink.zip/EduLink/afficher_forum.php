<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
  <meta charset="UTF-8" />
  <title>Détails du Forum</title>
</head>
<body>
<?php
// Include your database connection file
include('sql.php');

// Check if the forum ID is provided in the URL parameter
if (isset($_GET['id_forum'])) {
    $forum_id = $_GET['id_forum'];

    // Fetch the details of the specific forum post
    $query = "SELECT objet, description FROM forum WHERE id_forum =7";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("i", $forum_id);
    $stmt->execute();
    $stmt->bind_result($objet, $description);
    $stmt->fetch();
    $stmt->close();

    if ($objet && $description) {
        // Display the details of the forum post
        echo "<h1>$objet</h1>";
        echo "<p>$description</p>";

        // Form to add comments
        echo "<form action='add_comment.php' method='post'>";
        echo "<textarea name='comment' rows='4' cols='50' placeholder='Ajouter un commentaire'></textarea><br>";
        echo "<input type='hidden' name='forum_id' value='$forum_id'>";
        echo "<input type='submit' value='Envoyer'>";
        echo "</form>";

        // Display existing comments for this forum post
        // You need to implement this part
    } else {
        echo "Forum introuvable.";
    }
} else {
    echo "ID du forum non spécifié.";
}

// Close the database connection
$mysqli->close();
?>
</body>
</html>
